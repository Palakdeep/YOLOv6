# Yolov6 > 2023-10-08 4:55pm
https://universe.roboflow.com/projects-xnafr/yolov6-t5mfs

Provided by a Roboflow user
License: CC BY 4.0

